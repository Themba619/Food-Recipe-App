import React from 'react';
import { View, Text } from 'react-native';

const ProfileScreen = () => (
  <View>
    <Text>Profile Screen</Text>
  </View>
);

export default ProfileScreen;
