import React from 'react';
import { View, Text } from 'react-native';


const BookmarksScreen = () => (
  <View>
    <Text>Bookmarks Screen</Text>
  </View>
);


export default BookmarksScreen;
