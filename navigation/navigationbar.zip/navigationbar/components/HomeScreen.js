import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Image,
  StyleSheet,
} from 'react-native';
import Swiper from 'react-native-swiper';

const App = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [recipes, setRecipes] = useState([
    { id: 1, title: 'Pasta Recipe' },
    { id: 2, title: 'Pizza Recipe' },
    // Add more recipes here
  ]);

  const [videos, setVideos] = useState([
    { id: 1, url: 'video_url_1', user: 'User1', mealName: 'Spaghetti', time: '20 min' },
    { id: 2, url: 'video_url_2', user: 'User2', mealName: 'Pizza', time: '30 min' },
    // Add more videos here
  ]);

  const [userProfiles, setUserProfiles] = useState([
    { id: 1, username: 'user1' },
    { id: 2, username: 'user2' },
    // Add more user profiles here
  ]);

  const [popularCreators, setPopularCreators] = useState([
    { id: 1, username: 'creator1' },
    { id: 2, username: 'creator2' },
    // Add more popular creators here
  ]);

  return (
    <View style={styles.container}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search"
          value={searchQuery}
          onChangeText={(text) => setSearchQuery(text)}
        />
        <TouchableOpacity style={styles.searchButton}>
          {/* Add your search icon here */}
          <Text>🔍</Text>
        </TouchableOpacity>
      </View>

      {/* Recipe Options */}
      <ScrollView horizontal style={styles.optionsContainer}>
        {recipes.map((recipe) => (
          <TouchableOpacity key={recipe.id} style={styles.option}>
            <Text style={styles.optionText}>{recipe.title}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Video Swiper (Trending Videos) */}
      <Swiper
        style={styles.videoSwipeContainer}
        showsButtons={false}
        autoplay={true}
        loop={true}
      >
        {videos.map((video) => (
          <View key={video.id} style={styles.video}>
            {/* Video Component */}
            <Image source={{ uri: video.url }} style={styles.videoImage} />
            <Text style={styles.videoTitle}>{video.mealName}</Text>
            <View style={styles.videoUserInfo}>
              <Text style={styles.videoUser}>{video.user}</Text>
              <Text style={styles.videoTime}>Time: {video.time}</Text>
            </View>
            <TouchableOpacity style={styles.likeButton}>
              {/* Add a like button */}
              <Text>Like</Text>
            </TouchableOpacity>
          </View>
        ))}
      </Swiper>

      {/* Recent Videos */}
      <FlatList
        data={videos}
        horizontal
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.recentVideo}>
            <View style={styles.circularProfile}>
              {/* User Profile Picture */}
              <Text style={styles.popularCreatorText}>{item.user}</Text>
            </View>
            <Text style={styles.videoTitle}>{item.mealName}</Text>
            <Text style={styles.videoUser}>{item.user}</Text>
            <Text style={styles.videoTime}>Time: {item.time}</Text>
            <TouchableOpacity style={styles.likeButton}>
              {/* Add a like button */}
              <Text>Like</Text>
            </TouchableOpacity>
          </View>
        )}
      />

      {/* Popular Creators */}
      <FlatList
        data={popularCreators}
        horizontal
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.popularCreator}>
            <View style={styles.circularProfile}>
              {/* Profile Picture */}
              <Text style={styles.popularCreatorText}>{item.username}</Text>
            </View>
            <Text style={styles.popularCreatorName}>{item.username}</Text>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 10,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  searchInput: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginRight: 10,
    padding: 5,
  },
  searchButton: {
    width: 40,
    height: 40,
    backgroundColor: 'lightgray',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
  },
  optionsContainer: {
    marginBottom: 10,
  },
  option: {
    padding: 10,
    marginRight: 10,
    backgroundColor: 'lightgray',
    borderRadius: 5,
  },
  optionText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  videoSwipeContainer: {
    marginBottom: 10,
  },
  video: {
    width: '100%',
    height: 200,
    backgroundColor: 'lightgray',
    borderRadius: 10,
    alignItems: 'center',
  },
  videoImage: {
    width: '100%',
    height: '70%',
    borderRadius: 10,
  },
  videoTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  videoUserInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  videoUser: {
    fontSize: 14,
  },
  videoTime: {
    fontSize: 14,
  },
  likeButton: {
    backgroundColor: 'lightgray',
    padding: 5,
    borderRadius: 5,
    marginTop: 5,
  },
  recentVideo: {
    margin: 10,
    width: 150,
  },
  circularProfile: {
    width: 80,
    height: 80,
    backgroundColor: 'lightgray',
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  popularCreatorText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  popularCreatorName: {
    marginTop: 5,
    fontSize: 14,
  },
});

export default App;
