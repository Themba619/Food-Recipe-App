import React from 'react';
import { View, Text } from 'react-native';

const AddPageScreen = () => (
  <View>
    <Text>Add Page Screen</Text>
  </View>
);

export default AddPageScreen;
