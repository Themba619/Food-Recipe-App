// Comment.js
import React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

const Comment = ({ username, text, onPress }) => {
  return (
    <TouchableOpacity onPress={onPress}>
      <View>
        <Text style={{ fontWeight: 'bold' }}>{username}</Text>
        <Text>{text}</Text>
      </View>
    </TouchableOpacity>
  );
};

export default Comment;
