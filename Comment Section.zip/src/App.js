import React, { useState } from 'react';
import { View, ScrollView, TextInput, Button } from 'react-native';
import Comment from '../Comment';

const App = () => {
  const [comments, setComments] = useState([
    //{ id: 1, username: 'User1', text: 'This is the first comment.' },
    //{ id: 2, username: 'User2', text: 'Another comment here.' },
    // Add more initial comments if needed
  ]);

  const [newComment, setNewComment] = useState('');
  const [commentIdCounter, setCommentIdCounter] = useState(comments.length + 1);

  const handleCommentPress = (commentId) => {
    // Implement the desired action here, e.g., show comment details
    console.log(`Clicked on comment with ID ${commentId}`);
  };

  const handleAddComment = () => {
    if (newComment.trim() !== '') {
      const comment = {
        id: commentIdCounter,
        username: 'New User', // Replace with actual user info
        text: newComment,
      };
      setComments([...comments, comment]);
      setNewComment('');
      setCommentIdCounter(commentIdCounter + 1);
    }
  };

  return (
    <ScrollView>
      {comments.map((comment) => (
        <Comment
          key={comment.id}
          username={comment.username}
          text={comment.text}
          onPress={() => handleCommentPress(comment.id)}
        />
      ))}
      <TextInput
        placeholder="Enter your comment"
        value={newComment}
        onChangeText={(text) => setNewComment(text)}
      />
      <Button title="Add Comment" onPress={handleAddComment} />
    </ScrollView>
  );
};

export default App;
