import React from 'react';
import { FlatList } from 'react-native';
import Comment from '../Comment'; // Make sure Comment component is correctly imported

const CommentList = ({ comments }) => {
  return (
    <FlatList
      data={comments}
      keyExtractor={(comment) => comment.id.toString()} // Assuming each comment has a unique ID
      renderItem={({ item }) => (
        <Comment username={item.username} text={item.text} />
      )}
    />
  );
};

export default CommentList;
