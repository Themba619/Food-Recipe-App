//App
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import BloodTypeFilterScreen from './components/BloodTypeFilterScreen';
import BMICalculatorScreen from "./components/BMICalculatorScreen";
import InterestScreen from './components/InterestScreen';



const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="BMICalculator">
        <Stack.Screen
          name="BMI calculator"
          component={BMICalculatorScreen }
          options={{ title: 'BMICalculator' }}
        />
        <Stack.Screen
          name="BloodTypeFilter"
          component={BloodTypeFilterScreen}
          options={{ title: 'BloodTypeFilterScreen' }}
        />
        <Stack.Screen
          name="InterestScreen"
          component={InterestScreen}
          options={{ title: 'Interest' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
