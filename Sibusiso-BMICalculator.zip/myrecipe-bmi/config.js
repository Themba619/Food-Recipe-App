import { getFirestore } from '@react-native-firebase/firestore';
import { getAuth } from '@react-native-firebase/auth'; // Updated import statement
import { AppRegistry } from 'react-native';



const firebaseConfigCustom = {
  apiKey: 'AIzaSyDK8dnK7J7VRXOk2VB6iPyn2ATerXHTfHU',
  authDomain: 'myrecipe-58c34.firebaseapp.com',
  projectId: 'myrecipe-58c34',
  storageBucket: 'myrecipe-58c34.appspot.com',
  messagingSenderId: '469853786927',
  appId: '1:469853786927:web:ab19b4fb8d8c4cfeee47da',
};


const app = initializeApp(firebaseConfigCustom);
const auth = getAuth(app);
const firestore = getFirestore(app);

export default firebaseConfigCustom;