import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

const BloodTypeFilterScreen = () => {
  const [selectedBloodType, setSelectedBloodType] = useState('');
  const navigation = useNavigation();

  const handleBloodTypeSelect = (BloodType) => {
    setSelectedBloodType(BloodType);
    // Handle the selected blood type here, e.g., save it to Firebase
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.navigateButton}
        onPress={() => navigation.navigate('InterestsScreen')}
      >
        <Text style={styles.buttonText}>Navigate to Interests</Text>
      </TouchableOpacity>
      <Text style={styles.title}>Select Your Blood Type:</Text>
      <View style={styles.buttonGrid}>
        {/* Your blood type buttons */}
      </View>
    </View>
  );
};

const InterestsScreen = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Interests Screen</Text>
    </View>
  );
};

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="BloodTypeFilterScreen">
        <Stack.Screen name="BloodTypeFilterScreen" component={BloodTypeFilterScreen} />
        <Stack.Screen name="InterestsScreen" component={InterestsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f2f2f2',
  },
  title: {
    fontSize: 20,
    marginBottom: 20,
  },
  buttonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  navigateButton: {
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default App;
