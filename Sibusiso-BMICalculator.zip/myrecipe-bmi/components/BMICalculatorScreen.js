import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { ref, push } from '@react-native-firebase/database';

const BMICalculatorScreen = () => {
  const navigation = useNavigation();

  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmiResult, setBMIResult] = useState('');

  const calculateBMI = () => {
    const heightInMeters = parseFloat(height) / 100;
    const weightInKg = parseFloat(weight);
    const bmi = weightInKg / (heightInMeters * heightInMeters);
    setBMIResult(bmi.toFixed(2));

    // Push data to Firebase
    const bmiRef = ref(database, 'bmiRecords');
    push(bmiRef, { height, weight, bmi })
      .then(() => {
        console.log('BMI record saved successfully');
      })
      .catch((error) => {
        console.error('Error saving BMI record: ', error);
      });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.label}>Enter Height (cm):</Text>
      <TextInput
        style={styles.input}
        onChangeText={setHeight}
        value={height}
        keyboardType="numeric"
      />
      <Text style={styles.label}>Enter Weight (kg):</Text>
      <TextInput
        style={styles.input}
        onChangeText={setWeight}
        value={weight}
        keyboardType="numeric"
      />
      <Button title="Calculate BMI" onPress={calculateBMI} />
      <Text style={styles.result}>BMI Result: {bmiResult}</Text>
      <Button
        title="Go to Blood Type Filter"
        onPress={() => navigation.navigate('BloodTypeFilter')}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    borderRadius: 10,
    backgroundColor: '#f2f2f2',
  },
  label: {
    fontSize: 18,
    marginBottom: 10,
  },
  input: {
    width: 200,
    height: 40,
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 10,
    padding: 10,
  },
  result: {
    fontSize: 20,
    marginTop: 20,
    fontWeight: 'bold',
  },
});

export default BMICalculatorScreen;
