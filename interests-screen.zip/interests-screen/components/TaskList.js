import React, { useEffect, useState } from 'react';
import { View, Text, Button, FlatList } from 'react-native';
import firestore from '@react-native-firebase/firestore';

const TaskList = () => {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    const unsubscribe = firestore()
      .collection('tasks')
      .where('IsComplete', '==', false)
      .onSnapshot((querySnapshot) => {
        const updatedTasks = [];
        querySnapshot.forEach((documentSnapshot) => {
          updatedTasks.push({
            id: documentSnapshot.id,
            ...documentSnapshot.data(),
          });
        });
        setTasks(updatedTasks);
      });

    return () => unsubscribe();
  }, []);

  const completeTask = (taskId) => {
    firestore().collection('tasks').doc(taskId).update({
      IsComplete: true,
    });
  };

  const deleteTask = (taskId) => {
    firestore().collection('tasks').doc(taskId).delete();
  };

  return (
    <View>
      <Text>Task List</Text>
      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View>
            <Text>{item.Description}</Text>
            <Text>{item['Complete by']}</Text>
            <Button title="Complete" onPress={() => completeTask(item.id)} />
            <Button title="Delete" onPress={() => deleteTask(item.id)} />
          </View>
        )}
      />
    </View>
  );
};

export default TaskList;
