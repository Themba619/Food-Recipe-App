import React, { useState } from 'react';
import { View, TextInput, Button } from 'react-native';
import firestore from '@react-native-firebase/firestore';

const AddTask = () => {
  const [taskDescription, setTaskDescription] = useState('');
  const [completeBy, setCompleteBy] = useState('');

  const addTask = () => {
    if (taskDescription && completeBy) {
      firestore()
        .collection('tasks')
        .add({
          Description: taskDescription,
          'Complete by': completeBy,
          IsComplete: false,
        })
        .then(() => {
          console.log('Task added!');
          setTaskDescription('');
          setCompleteBy('');
        })
        .catch((error) => {
          console.error('Error adding task: ', error);
        });
    }
  };

  return (
    <View>
      <TextInput
        placeholder="Task description"
        value={taskDescription}
        onChangeText={(text) => setTaskDescription(text)}
      />
      <TextInput
        placeholder="Complete by (YYYY-MM-DD)"
        value={completeBy}
        onChangeText={(text) => setCompleteBy(text)}
      />
      <Button title="Add Task" onPress={addTask} />
    </View>
  );
};

export default AddTask;
