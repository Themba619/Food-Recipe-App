import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, FlatList } from 'react-native';

const App = () => {
  const [currentPage, setCurrentPage] = useState(0);
  const itemsPerPage = 6; // Number of items to display per page

  const categories = [
    'Italian', 'Mexican', 'Thai Cruisine', 'Sea Food', 'French', 'Greek Cruisine',
    'Dairy Foods', 'Mexican', 'Italian', 'Vegetarian', 'Desserts', 'Asian', 'African Food'
  ];

  const nextPage = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  const prevPage = () => {
    setCurrentPage((prevPage) => prevPage - 1);
  };

  // Calculate the range of categories to display based on the current page
  const startIndex = currentPage * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const displayedCategories = categories.slice(startIndex, endIndex);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Interests</Text>
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchBar}
          placeholder="Search for favorite dishes"
        />
        <TouchableOpacity style={styles.searchButton}>
          <Text>Search</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        data={displayedCategories}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.categoryButton}>
            <Text>{item}</Text>
          </TouchableOpacity>
        )}
      />
      <View style={styles.paginationContainer}>
        <TouchableOpacity
          style={[styles.paginationButton, { marginRight: 10 }]}
          onPress={prevPage}
          disabled={currentPage === 0}
        >
          <Text>Previous</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.paginationButton}
          onPress={nextPage}
          disabled={endIndex >= categories.length}
        >
          <Text>Next</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f4',
    padding: 20,
  },
  title: {
    fontSize: 24,
    textAlign: 'center',
    margin: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  searchBar: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#42b883',
    borderRadius: 25,
    padding: 10,
    marginRight: 10,
  },
  searchButton: {
    backgroundColor: '#42b883',
    borderRadius: 25,
    padding: 10,
  },
  categoryButton: {
    backgroundColor: '#42b883',
    borderRadius: 25,
    padding: 10,
    margin: 5,
  },
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  paginationButton: {
    backgroundColor: '#42b883',
    borderRadius: 25,
    padding: 10,
  },
});

export default App;
