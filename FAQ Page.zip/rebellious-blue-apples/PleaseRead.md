1. The packages installed here are enough for you to achieve the given task.
2. Do not forget to login to save your work.

Icons can be found here: https://icons.expo.fyi/Index