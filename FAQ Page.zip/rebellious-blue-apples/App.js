import React, { useState } from 'react';
import { View, Text, TouchableOpacity, SafeAreaView } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

const styles = {
  faqQuestionIcon: {
    cursor: 'pointer',
  },
  faqQuestionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  faqQuestionText: {
    flex: 1,
    marginRight: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#3c3c3c',
    borderBottomWidth: 3,
    borderBottomColor: '#56E3B8',
  },
  headerH1: {
    color: '#EEE',
    fontSize: 28,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
};

function App() {
  const [faqs, setfaqs] = useState([
    {
      question: 'How do I create an account?',
      answer:
        'To create an account, click on the "Sign Up" button on the home page, then follow the instructions to provide your details and set up your account.',
      open: false,
    },
    {
      question: 'Can I reset my password if I forget it?',
      answer:
        'Yes, you can reset your password if you forget it. Click on the "Forgot Password" link on the login page and follow the instructions to reset your password.',
      open: false,
    },
    {
      question: 'How can I search for recipes?',
      answer:
        'You can search for recipes by using the search bar on the home screen. Just enter the name of the dish or an ingredient, and you\'ll find relevant recipes.',
      open: false,
    },
    {
      question: 'How do I save a recipe to my favorites?',
      answer:
        'To save a recipe, open the recipe\'s details page, and click the \'Add to Favorites\' button. You can access your saved recipes in the Favorites section of the app.',
      open: false,
    },
    {
      question: 'Can I customize serving sizes for a recipe?',
      answer:
        'Yes, you can customize serving sizes by adjusting the portion size on the recipe details page. The ingredient quantities will automatically update based on your preference.',
      open: false,
    },
    {
      question: 'How do I share a recipe with friends?',
      answer:
        'You can share a recipe by clicking the \'Share\' button on the recipe details page. You can share it via email, messaging apps, or on social media.',
      open: false,
    },
    {
      question: 'How often are new recipes added to the app?',
      answer:
        'We regularly update the app with new recipes and content. You can expect fresh recipes and seasonal dishes to be added on a weekly basis.',
      open: false,
    },
    {
      question: 'What dietary preferences are supported in the app?',
      answer:
        'Our app supports a variety of dietary preferences, including vegetarian, vegan, gluten-free, and more. You can filter recipes based on your dietary requirements.',
      open: false,
    },
    {
      question: 'Do you provide video tutorials for cooking techniques?',
      answer:
        'We offer a library of video tutorials covering various cooking techniques, tips, and tricks to help you enhance your culinary skills.',
      open: false,
    },
    {
      question: 'Are the recipes suitable for beginners in cooking?',
      answer:
        'We have a wide range of recipes, including those designed for beginners. Each recipe includes clear instructions and cooking tips to help users of all skill levels.',
      open: false,
    },
    {
      question: 'How can I submit my own recipe to the app?',
      answer:
        'Currently, we do not support user-submitted recipes, however, we are working on adding this feature in the future. Stay tuned.',
      open: false,
    },
    {
      question: 'How can I adjust recipes for special dietary restrictions or allergies?',
      answer:
        'You can adjust recipes to accommodate dietary restrictions or allergies by using our filters or making ingredient substitutions.',
      open: false,
    },
    {
      question: 'Do you have international or regional cuisines in the app?',
      answer:
        'Absolutely! Our app offers a wide range of international and regional cuisines. You can explore and try recipes from around the world.',
      open: false,
    },
    {
      question: 'Can I leave comments and ratings on recipes?',
      answer:
        'Yes, you can leave comments and ratings on recipes to share your feedback and experiences with other users. Your input is valuable to the community.',
      open: false,
    },
    {
      question: 'How can I change my password or update my account information?',
      answer:
        'You can change your password and update your account information in the "Accounts" section of the app.',
      open: false,
    },
    {
      question: 'Help and support',
      answer:
        'Our team is available 24 hours a day. You can contact them at MyFoodRecipe2023@gmail.com. One of our dedicated team members will respond to you as soon as possible.',
      open: false,
    },
  ]);

  const toggleFAQ = (index) => {
    setfaqs((prevFaqs) =>
      prevFaqs.map((faq, i) => {
        if (i === index) {
          faq.open = !faq.open;
        }
        return faq;
      })
    );
  };

  return (
    <SafeAreaView style={styles.body}>
      <View style={styles.header}>
        <Text style={styles.headerH1}>People may also ask:</Text>
      </View>
      <View style={styles.faqs}>
        {faqs.map((faq, i) => (
          <View key={i}>
            <TouchableOpacity
              style={styles.faqQuestionContainer}
              onPress={() => toggleFAQ(i)}
            >
              <Text style={styles.faqQuestionText}>{faq.question}</Text>
              <View style={styles.faqQuestionIcon}>
                <AntDesign
                  name={faq.open ? 'upcircleo' : 'downcircleo'}
                  size={24}
                  color="#3c3c3c"
                />
              </View>
            </TouchableOpacity>
            {faq.open && <Text style={styles.faqAnswer}>{faq.answer}</Text>}
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
}

export default App;
