//ResultScreen


import React, { useState } from 'react';
import { View, FlatList, Text, Image, StyleSheet, TouchableOpacity} from 'react-native';

const SearchResults = () => {
  const [data, setData] = useState([
    { id: 1, title: 'Item 1', image: 'https://via.placeholder.com/150', time: '60 min', profilepic: 'https://via.placeholder.com/150', username: 'username' },
    { id: 2, title: 'Item 2', image: 'https://via.placeholder.com/150', time: '60 min', profilepic: 'https://via.placeholder.com/150', username: 'username' },
    { id: 3, title: 'Item 3', image: 'https://via.placeholder.com/150', time: '60 min', profilepic: 'https://via.placeholder.com/150', username: 'username' },
    { id: 4, title: 'Item 4', image: 'https://via.placeholder.com/150', time: '60 min', profilepic: 'https://via.placeholder.com/150', username: 'username' },
    // Add more items here
  ]);

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
    <TouchableOpacity>
      <View style={{flexDirection: 'row'}}>
        <Image source={{ uri: item.profilepic }} style={{width: 30, height: 30, alignItems: 'center', marginBottom: 10, marginRight: 10}}/>
        <Text style={styles.time}>{item.username}</Text>
      </View>
      <Image source={{ uri: item.image }} style={styles.image} />
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.time}>{item.time}</Text>
    </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
    <Text style={{fontSize: 20, fontWeight: 'bold'}}>Search Results</Text>
    <FlatList
      data={data}
      renderItem={renderItem}
      keyExtractor={(item) => item.id.toString()}
      numColumns={2}
    />
    </View>
  );
};

const styles = StyleSheet.create({

  container:{
    position: 'relative',
    bottom: 50
  },
  itemContainer: {
    flex: 1,
    margin: 10,
    alignItems: 'center',
    padding: 10,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 10,
  },
  title: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: 'bold',
  },

  time:{
    color: 'gray'
  }
});

export default SearchResults;