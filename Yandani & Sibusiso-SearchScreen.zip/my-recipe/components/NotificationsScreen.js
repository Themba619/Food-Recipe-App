import React from 'react';
import { View, Text, FlatList } from 'react-native';

const NotificationsScreen = () => {
  // Sample notifications data
  const notifications = [
    { id: 1, text: 'You have a new comment on your post' },
    { id: 2, text: 'John Smith commented on your post' },
    // Add more notifications as needed
  ];
  
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <FlatList
        data={notifications}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ marginVertical: 10 }}>
            <Text>{item.text}</Text>
          </View>
        )}
      />
    </View>
  );
};

export default NotificationsScreen;
