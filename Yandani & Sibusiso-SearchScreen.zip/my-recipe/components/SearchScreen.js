//SearchScreen
import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, StyleSheet, FlatList, Text, TouchableOpacity } from 'react-native';

const SearchScreen = ({ navigation }) => {
  const [searchText, setSearchText] = useState('');
  const [searchSuggestions, setSearchSuggestions] = useState([]);
  const [recentSearches, setRecentSearches] = useState([]);

  const simulatedSearchSuggestions = ['Chinese', 'Indian', 'Sea Food','Mexican', 'Dairy'];
  const simulatedRecentSearches = ['French', 'Greek-Cuisine', 'Vegetarian'];

  useEffect(() => {
    setSearchSuggestions(simulatedSearchSuggestions);
    setRecentSearches(simulatedRecentSearches);
  }, []);

  const handleSearch = () => {
    if (searchText && !recentSearches.includes(searchText)) {
      setRecentSearches([searchText, ...recentSearches]);
    }

    navigation.navigate('Results', { searchText });
  };

  const renderSearchItem = ({ item }) => (
    <TouchableOpacity
      style={styles.searchItem}
      onPress={() => {
        setSearchText(item);
        handleSearch();
      }}
    >
      <Text>{item}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.searchBar}>
        <TextInput
          style={styles.input}
          placeholder="Search..."
          value={searchText}
          onChangeText={text => setSearchText(text)}
        />
        <Button title="Search" onPress={handleSearch} />
      </View>

      <View style={styles.suggestionsContainer}>
        <Text style={styles.suggestionsTitle}>Search Suggestions:</Text>
        <FlatList
          horizontal
          data={searchSuggestions}
          renderItem={renderSearchItem}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>

      <View style={styles.recentSearchesContainer}>
        <Text style={styles.recentSearchesTitle}>Recent Searches:</Text>
        <FlatList
          horizontal
          data={recentSearches}
          renderItem={renderSearchItem}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    padding: 10,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 10,
    borderRadius: 5,
    backgroundColor: 'white',
    marginRight:8,
  },
  suggestionsContainer: {
    marginBottom: 20,
  },
  suggestionsTitle: {
    fontWeight: 'bold',
    marginBottom: 10,
  },
  searchItem: {
    padding: 10,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: 'lightgray',
    marginRight: 10,
  },
  recentSearchesContainer: {},
  recentSearchesTitle: {
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

export default SearchScreen;